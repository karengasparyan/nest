import {InjectModel} from "@nestjs/mongoose";
export const InjectMongoModel = InjectModel;
