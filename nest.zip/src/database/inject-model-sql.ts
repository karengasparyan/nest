import {InjectModel} from "@nestjs/sequelize";
export const InjectSqlModel = InjectModel;
